require("./Databases/module.js")

//========= [ Setting Owner ]  =========//
global.no = "6283840073203"
global.owner = "XPanzZyy - Official"
global.bot = "XPanzZyyBotz"
global.v = "Alpha"
global.welcome = false
global.autoread = true
global.anticall = true

//========= [ Setting Lainya ]  =========//
global.own = "XPanzZyy - Official"
global.log = "𖣖"
global.ch = "https://whatsapp.com/channel/0029VahUbrs90x2wGeaWAc14"
global.bot = "XPanzZyyBotz"
global.ver = "Alpha"
global.wa = "https://files.catbox.moe/ict22l.jpg"
global.image = "https://files.catbox.moe/ict22l.jpg"

//========= [ Setting Message ]  =========//
global.msg = {
"error": "Maaf Adanya Sistem Error Pada Fitur Ini!!",
"done": "Berhasil🕊", 
"wait": "Wait To Proses🕊", 
"owner": "`You Now Owner`", 
"developer": "`You Now Development`"
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})